// content.js

// Twitchのチャットメッセージ要素からユーザー名を取得する関数
function getUsernameFromMessage(messageNode) {
    // 画面の表示名ではなく、HTMLタグに埋め込まれた正確なTwitch IDを取得する
    const username = messageNode.getAttribute('data-a-user');
    if (username) {
        return username.trim().toLowerCase();
    }
    return null;
}

// ランク情報をもとに画面に挿入する要素（バッジ）を生成する関数
function createEmblemElement(rankData) {
    const container = document.createElement('span');
    container.style.display = 'inline-flex';
    container.style.alignItems = 'center';
    container.style.marginLeft = '4px';
    container.style.marginRight = '4px';
    container.style.verticalAlign = 'middle';

    if (rankData.tier === 'UNRANKED' || !rankData.tier) {
        container.textContent = '[UNRANKED]';
        container.style.color = '#808080';
        container.style.fontSize = '12px';
        container.style.fontWeight = 'bold';
        return container;
    }

    // テキストベースのバッジとして表示
    container.textContent = `[${rankData.tier} ${rankData.rank}]`;
    container.style.fontSize = '12px';
    container.style.fontWeight = 'bold';

    // ランクごとの文字色設定
    const colors = {
        'IRON': '#434b4d',
        'BRONZE': '#8c510a',
        'SILVER': '#80989d',
        'GOLD': '#cd8837',
        'PLATINUM': '#4e9996',
        'EMERALD': '#28b463',
        'DIAMOND': '#576bce',
        'MASTER': '#9d48e0',
        'GRANDMASTER': '#e04848',
        'CHALLENGER': '#f4c874'
    };
    container.style.color = colors[rankData.tier] || '#ffffff';

    return container;
}

// 追加されたメッセージ要素を処理する関数
function processChatMessage(messageNode) {
    // 二重処理を防止するためのフラグ確認
    if (messageNode.dataset.rankProcessed === 'true') return;
    messageNode.dataset.rankProcessed = 'true';

    const username = getUsernameFromMessage(messageNode);
    if (!username) return;

    // background.jsに通信を依頼し、結果を受け取る
    chrome.runtime.sendMessage(
        { type: 'FETCH_RANK', username: username },
        (response) => {
            // エラー時や取得失敗時は表示処理を中断（チャット自体は正常に表示させる）
            if (chrome.runtime.lastError || !response || !response.success || response.data.error) {
                return;
            }

            const rankData = response.data;
            const emblemElement = createEmblemElement(rankData);
            
            // ユーザー名の要素を探して、その後ろにエンブレムを挿入
            const nameContainer = messageNode.querySelector('.chat-author__display-name');
            if (nameContainer && nameContainer.parentNode) {
                nameContainer.parentNode.insertBefore(emblemElement, nameContainer.nextSibling);
            }
        }
    );
}

// Twitchのチャット欄（画面全体）を監視する設定
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
                // 追加されたノード自体がメッセージ要素の場合
                if (node.classList.contains('chat-line__message')) {
                    processChatMessage(node);
                } 
                // 追加されたノードの子要素にメッセージが含まれている場合
                else {
                    const messages = node.querySelectorAll('.chat-line__message');
                    messages.forEach(msg => processChatMessage(msg));
                }
            }
        }
    }
});

// 監視を開始する関数
function startObserving() {
    // 画面全体を監視対象とすることで、Twitchの枠組み変更によるエラーを回避
    observer.observe(document.body, { childList: true, subtree: true });
}

// 実行開始
startObserving();