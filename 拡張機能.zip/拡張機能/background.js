// background.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'FETCH_RANK') {
        const username = request.username;
        
        // 通信先をローカルから本番サーバー（Cloud Run）のURLへ変更
        const apiUrl = 'https://twitchrank-server-932555910114.asia-northeast1.run.app/api/get-rank';

        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ twitchName: username })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            sendResponse({ success: true, data: data });
        })
        .catch(error => {
            console.error('ランク取得エラー:', error);
            sendResponse({ success: false, error: error.message });
        });

        // 非同期でsendResponseを呼び出すための記述
        return true;
    }
});